1 - Quad-Remesher engine makes use of some libraries of SuiteSparse 5.6.0 under the LGPL v2.1 license.
Quad-Remesher engine is using dynamic linking with these libraries. 

A copy of the LGPL license for SuiteSparse is included in QuadRemesher's distribution (in the file named "lesser.txt"),

Quad-Remesher is using the following modules of the SuiteSparse library:
- AMD
- CAMD
- CCOLAMD
- COLAMD
- CholMod/Cholesky
- CholMod/Core

The source code for the SuiteSparse 5.6.0 library may be downloaded from: http://faculty.cse.tamu.edu/davis/suitesparse.html
The source code for the SuiteSparse 5.6.0 library may be obtained from EXOSIDE by asking at contact@exoside.com


2 - Quad-Remesher engine makes use of the "Triangle" library.
Library: Triangle - A Two-Dimensional Quality Mesh Generator and Delaunay Triangulator. - Version 1.6
Copyright: Jonathan Richard Shewchuk
You can download the "Triangle" library here: https://www.cs.cmu.edu/~quake/triangle.html 
