1 - Quad-Remesher 'License Manager' makes use of some Qt 5.12.5 libraries under the LGPL v3 license.
Quad-Remesher engine is using dynamic linking with these libraries. 

A copy of the GNU LGPL v3 is included in QuadRemesher's distribution (in the file named "lgpl-3.0.txt"),
It may also be found online at this adress: https://www.gnu.org/licenses/lgpl-3.0.en.html 

The source code for Qt 5.12.5 may be downloaded at: https://download.qt.io/archive/qt/5.12/5.12.5/single/
The source code for Qt 5.12.5 may be obtained from EXOSIDE by asking at contact@exoside.com

